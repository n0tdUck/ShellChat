@echo off
rem Registers the native messaging host with Microsoft Edge for the current user.
set "KEY=HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.example.cmd_bridge"
reg add "%KEY%" /ve /t REG_SZ /d "%~dp0com.example.cmd_bridge.json" /f
if errorlevel 1 (
  echo Registration failed.
) else (
  echo Registered. Restart Edge, then click the CMD Bridge toolbar button.
)
if not exist "%~dp0..\python.exe" echo WARNING: bundled python.exe was not found in "%~dp0..".
pause
