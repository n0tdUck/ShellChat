@echo off
rem Edge launches this file. Errors from Python go to host.log next to this file.
rem Uses the python.exe bundled one folder up (test1\python.exe), not the installed Python.
setlocal
set "LOG=%~dp0host.log"
set "PYTHON=%~dp0..\python.exe"
echo [%date% %time%] host launched >>"%LOG%"
if not exist "%PYTHON%" (
  echo [%date% %time%] bundled python not found at "%PYTHON%" >>"%LOG%"
  exit /b 9009
)
"%PYTHON%" -u "%~dp0cmd_host.py" %* 2>>"%LOG%"
echo [%date% %time%] host exited with code %errorlevel% >>"%LOG%"
